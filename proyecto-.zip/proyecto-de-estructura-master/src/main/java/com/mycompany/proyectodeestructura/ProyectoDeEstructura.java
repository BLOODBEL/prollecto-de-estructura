package com.mycompany.proyectodeestructura;

/**
 *
 * @author ADMIN
 */
public class ProyectoDeEstructura {

    public static void main(String[] args) {
        System.out.println("Hello Word!");
    }
}
