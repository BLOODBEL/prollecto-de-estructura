package com.mycompany.proyectodeestructura;

/**
 *
 * @author ADMIN
 */
public class Robots {
    
}
